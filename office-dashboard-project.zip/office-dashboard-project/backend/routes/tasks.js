const express = require('express');
const router = express.Router();
const Task = require('../models/Task');
const User = require('../models/User');
const jwt = require('jsonwebtoken');
const JWT_SECRET = process.env.JWT_SECRET || 'secret123';
const auth = (req,res,next)=>{
  const header = req.headers.authorization;
  if (!header) return res.status(401).json({ message: 'No token' });
  const token = header.split(' ')[1];
  try{
    const data = jwt.verify(token, JWT_SECRET);
    req.user = data;
    next();
  }catch(e){ return res.status(401).json({ message: 'Invalid token' }); }
};
// Create task (manager)
router.post('/', auth, async (req,res)=>{
  if (req.user.role !== 'manager') return res.status(403).json({ message: 'Forbidden' });
  const { title, description, deadline, assignee } = req.body;
  try{
    const task = new Task({ title, description, deadline, assignee });
    await task.save();
    res.json(task);
  }catch(e){ res.status(500).json({ message: e.message }); }
});
// Get tasks (manager gets all, employee gets own)
router.get('/', auth, async (req,res)=>{
  try{
    let tasks;
    if (req.user.role === 'manager') tasks = await Task.find().populate('assignee','name email role');
    else tasks = await Task.find({ assignee: req.user.id }).populate('assignee','name email role');
    res.json(tasks);
  }catch(e){ res.status(500).json({ message: e.message }); }
});
// Update task (assignee or manager)
router.put('/:id', auth, async (req,res)=>{
  try{
    const task = await Task.findById(req.params.id);
    if (!task) return res.status(404).json({ message: 'Not found' });
    if (req.user.role !== 'manager' && String(task.assignee) !== req.user.id) return res.status(403).json({ message: 'Forbidden' });
    Object.assign(task, req.body);
    await task.save();
    res.json(task);
  }catch(e){ res.status(500).json({ message: e.message }); }
});
module.exports = router;
