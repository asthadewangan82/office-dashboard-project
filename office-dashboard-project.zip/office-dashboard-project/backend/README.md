# Backend

Run `npm install` then `npm run dev`. Copy `.env.example` to `.env` and set `MONGO_URI` and `JWT_SECRET`.

For quick demo you can register a user via `/api/auth/register` then login `/api/auth/login`.
