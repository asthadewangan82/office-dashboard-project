# Frontend

This is a minimal Vite + React frontend. Run `npm install` then `npm run dev`. Configure API URL with `VITE_API_URL` in `.env`.