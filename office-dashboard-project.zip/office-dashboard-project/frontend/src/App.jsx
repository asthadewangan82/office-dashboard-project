        import React, { useState, useEffect } from 'react';
        import './styles.css';
        const API = import.meta.env.VITE_API_URL || 'http://localhost:5000';
        function App(){
  const [token,setToken]=useState(localStorage.getItem('token')||'');
  const [user,setUser]=useState(JSON.parse(localStorage.getItem('user')||'null'));
  const [tasks,setTasks]=useState([]);
  const [form,setForm]=useState({email:'',password:''});
  useEffect(()=>{ if(token) fetchTasks(); },[token]);
  async function login(){
    const res = await fetch(API + '/api/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(form)});
    const data = await res.json();
    if (data.token){ setToken(data.token); setUser(data.user); localStorage.setItem('token', data.token); localStorage.setItem('user', JSON.stringify(data.user)); }
    else alert(data.message||'Login failed');
  }
  async function fetchTasks(){
    const res = await fetch(API + '/api/tasks',{ headers:{ Authorization: 'Bearer '+token } });
    const data = await res.json();
    setTasks(data);
  }
  async function assign(){
    const title = prompt('Task title'); if(!title) return;
    const deadline = prompt('Deadline (YYYY-MM-DD)');
    const assigneeEmail = prompt('Assignee email');
    // find user id via backend? for now send assignee email in body
    const res = await fetch(API + '/api/tasks',{ method:'POST', headers:{ 'Content-Type':'application/json', Authorization: 'Bearer '+token }, body: JSON.stringify({ title, description:'', deadline, assignee: '' }) });
    if(res.ok) fetchTasks(); else alert('Assign failed');
  }
  return (
    <div style={{fontFamily:'Inter, sans-serif', padding:20}}>
      <h1>Office Dashboard (MERN Starter)</h1>
      {!token ? (
        <div style={{maxWidth:360}}>
          <h3>Login</h3>
          <input placeholder='email' value={form.email} onChange={e=>setForm({...form,email:e.target.value})} />
          <br/>
          <input placeholder='password' type='password' value={form.password} onChange={e=>setForm({...form,password:e.target.value})} />
          <br/>
          <button onClick={login}>Login</button>
        </div>
      ) : (
        <div>
          <div style={{display:'flex',justifyContent:'space-between', alignItems:'center'}}>
            <div>Signed in as: {user?.name} ({user?.role})</div>
            <div>
              {user?.role==='manager' && <button onClick={assign}>Assign Task</button>}
              <button onClick={()=>{localStorage.clear();setToken('');setUser(null);setTasks([]);}}>Logout</button>
            </div>
          </div>
          <h3>Tasks</h3>
          <ul>
            {tasks.map(t=> (
              <li key={t._id}>{t.title} - {t.status} - {t.progress}% - Assignee: {t.assignee?.name || t.assignee}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
export default App;
