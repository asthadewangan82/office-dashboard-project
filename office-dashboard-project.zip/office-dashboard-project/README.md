# Office Dashboard - MERN Starter

This repository contains a minimal MERN starter for your Office Task Dashboard.

## Quick start

1. Start MongoDB (e.g. `mongod`)
2. Backend:
   - `cd backend`
   - `npm install`
   - copy `.env.example` to `.env` and set values
   - `npm run dev`
3. Frontend:
   - `cd frontend`
   - `npm install`
   - `npm run dev`

Notes: This is a starter scaffold. Frontend uses a minimal UI and the assign flow is simplified for demo.
